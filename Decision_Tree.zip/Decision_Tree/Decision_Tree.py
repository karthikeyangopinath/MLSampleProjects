import numpy as np;
import pandas as pd;
import sklearn as sk;
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split;
from sklearn import preprocessing
from sklearn import tree
from sklearn import metrics


#This is used for Encoding and Decoding the ecoded values
def encode_decode_df(df):
    cols=list(df.columns.values.tolist())
    #print(cols)
    encode = preprocessing.LabelEncoder()
    encoding_dictionary={}
    decoding_dictionary={}
    for name in cols: 
#        print(type(df[column]))
        df[name]= encode.fit_transform(df[name])
#        print(name)
        keys=encode.classes_
#        print(keys)
        values=encode.transform(encode.classes_)
#        print(values)
        #print(dict[name]=dict(zip(keys,values)))
        encoding_dictionary.update({name:dict(zip(keys,values))})
        decoding_dictionary.update({name:dict(zip(values,keys))})
        
    return df,encoding_dictionary,decoding_dictionary

#This function is used to check if test and train instances are mutually exclusive. If not, the values from the training instances that matches the test instances will be removed.
def test_instances_checker(x_train,x_test,y_train,y_test):

#Combining the test and train data
    train_combined=x_train.merge(y_train,left_index=True,right_index=True)
    test_combined=x_test.merge(y_test,left_index=True,right_index=True)

#Creating the Key for removing the instances from the test cases
    train_combined['Key_Match']=train_combined[train_combined.columns[0]].astype(str)+train_combined[train_combined.columns[1]].astype(str)+train_combined[train_combined.columns[2]].astype(str)+train_combined[train_combined.columns[3]].astype(str)+train_combined[train_combined.columns[4]].astype(str)+train_combined[train_combined.columns[5]].astype(str)+train_combined[train_combined.columns[6]].astype(str)+train_combined[train_combined.columns[7]].astype(str)+train_combined[train_combined.columns[8]].astype(str)+train_combined[train_combined.columns[9]].astype(str)+train_combined[train_combined.columns[10]].astype(str)+train_combined[train_combined.columns[11]].astype(str)+train_combined[train_combined.columns[12]].astype(str)
    test_combined['Key_Match']=test_combined[test_combined.columns[0]].astype(str)+test_combined[test_combined.columns[1]].astype(str)+test_combined[test_combined.columns[2]].astype(str)+test_combined[test_combined.columns[3]].astype(str)+test_combined[test_combined.columns[4]].astype(str)+test_combined[test_combined.columns[5]].astype(str)+test_combined[test_combined.columns[6]].astype(str)+test_combined[test_combined.columns[7]].astype(str)+test_combined[test_combined.columns[8]].astype(str)+test_combined[test_combined.columns[9]].astype(str)+test_combined[test_combined.columns[10]].astype(str)+test_combined[test_combined.columns[11]].astype(str)+test_combined[test_combined.columns[12]].astype(str)

    train_combined=train_combined[~train_combined['Key_Match'].isin(test_combined['Key_Match'])]
    x_train_final=train_combined.iloc[:,:12]
    y_train_final=train_combined.iloc[:,12:13]
    x_test_final=test_combined.iloc[:,:12]
    y_test_final=test_combined.iloc[:,12:13]
    return x_train_final,x_test_final,y_train_final,y_test_final

#THis is used to print the train and test ratio
def print_train_test_ratio(x_train,x_test,y_train,y_test):
    print("\033[1m",'Training and Test Data Separation - All Data Except Missing Values',"\033[0m")
    print("\033[1m",'Size of the Traning Data: ',"\033[0m",len(x_train),'\n')
    print("\033[1m",'Size of the Test Data: ',"\033[0m",len(x_test),'\n')
    print("\033[1m",'Test Size: ',"\033[0m",round(len(x_test)/(len(x_test)+len(x_train)),2),'\n')
    test_size=round(len(x_test)/(len(x_test)+len(x_train)),2)
    return test_size

#Post Pruning - this was used during testing to find the best parameter ccp_calpha to avoid overfitting and optimise the result
def Pruning_Param(clf,x_train,y_train,x_test,y_test):
    clf = tree.DecisionTreeClassifier()
    path = clf.cost_complexity_pruning_path(x_train, y_train)
    ccp_alphas, impurities = path.ccp_alphas, path.impurities
    fig, ax = plt.subplots()
    ax.plot(ccp_alphas[:-1], impurities[:-1], marker='o', drawstyle="steps-post")
    ax.set_xlabel("effective alpha")
    ax.set_ylabel("total impurity of leaves")
    ax.set_title("Total Impurity vs effective alpha for training set")

    clfs = []
    for ccp_alpha in ccp_alphas:
        if ccp_alpha<=0:
            ccp_alpha=0
        clf = tree.DecisionTreeClassifier( ccp_alpha=ccp_alpha)
        clf.fit(x_train, y_train)
        clfs.append(clf)
    print("Number of nodes in the last tree is: {} with ccp_alpha: {}".format(clfs[-1].tree_.node_count, ccp_alphas[-1]))
    clfs = clfs[:-1]
    ccp_alphas = ccp_alphas[:-1]

    node_counts = [clf.tree_.node_count for clf in clfs]
    depth = [clf.tree_.max_depth for clf in clfs]
    fig, ax = plt.subplots(2, 1)
    ax[0].plot(ccp_alphas, node_counts, marker='o', drawstyle="steps-post")
    ax[0].set_xlabel("alpha")
    ax[0].set_ylabel("number of nodes")
    ax[0].set_title("Number of nodes vs alpha")
    ax[1].plot(ccp_alphas, depth, marker='o', drawstyle="steps-post")
    ax[1].set_xlabel("alpha")
    ax[1].set_ylabel("depth of tree")
    ax[1].set_title("Depth vs alpha")
    fig.tight_layout()

    train_scores = [clf.score(x_train, y_train) for clf in clfs]
    test_scores = [clf.score(x_test, y_test) for clf in clfs]

    fig, ax = plt.subplots()
    ax.set_xlabel("alpha")
    ax.set_ylabel("accuracy")
    ax.set_title("Accuracy vs alpha for training and testing sets")
    ax.plot(ccp_alphas, train_scores, marker='o', label="train",drawstyle="steps-post")
    ax.plot(ccp_alphas, test_scores, marker='o', label="test",drawstyle="steps-post")
    ax.legend()
    plt.show()
    
    ccp_alpha_df=pd.DataFrame(np.transpose([np.array(test_scores),np.array(clfs)]))
    final_ccp_alpha_val=ccp_alpha_df[ccp_alpha_df[0]==ccp_alpha_df[0].max()][1]
    print('CCP_VALUE that increases the test accuracy is: ',final_ccp_alpha_val)



def all_metrics(x_train,y_train,x_test,y_test,clf):
#predict the labels for the test set
    y_hat = clf.predict(x_test)

#count the number of correctly predicted labels
    count=0.0
    for i in range(len(y_test)):
        if (y_hat[i]==y_test[i]):
            count +=1
    score =count/len(x_test)
    print("\033[1m",'number of correct predictions = ',"\033[0m",count,'out of',len(y_test),'is ',score)
    

#Using the sckilearn score function
    print('traning score=',clf.score(x_train,y_train))
    print('test score=',clf.score(x_test,y_test))

#Confusion Matrix
    cm = metrics.confusion_matrix(y_test,y_hat)
    print('Confusion Matrix:\n',cm)

#Precision Score
    precision = metrics.precision_score(y_test,y_hat,average=None)
    print('Precision:',precision)

#Recall
    recall = metrics.recall_score(y_test,y_hat,average=None)
    print('Recall:',recall)

#F1 Score
    f1= metrics.f1_score(y_test,y_hat,average=None)
    print('F1 Score:',f1)

#Error Rate
    print("\033[1m",'Error Rate on Training Data:',"\033[0m",1-clf.score(x_train,y_train))
    print("\033[1m",'Error Rate on Test Data:',"\033[0m",1-clf.score(x_test,y_test))
    
    return 1-clf.score(x_test,y_test)



#######################################THE MAIN CODE STARTS HERE#########################
#The main code starts here
print("\033[1m",'\nDecision Trees',"\033[0m")
adult_df=pd.read_csv("adult.csv")
print('The Data Set is imported successfully \n')
del adult_df['fnlwgt']
adult_df=adult_df.rename(columns={'class':'class_name'})
adult_df.columns=adult_df.columns.str.replace("-","_")
print("\033[1m",'Some Data Cleaning Operations Performed\n',"\033[0m",'1.Removal of the fnlwgt column as it is not required\n','2. Using standard names for the columns')

print("\033[1m",'Printing out the Stats below\n',"\033[0m")
print('-----------------------------\n')
#Total number of records/isntances in DF
No_Instances=len(adult_df.axes[0])
#Number of records in individual attribultes column
Total_No_Attr_Values=sum(adult_df.iloc[:,:13].count())
#Number of missing values in a dataframe per attribute wise
No_missing_values_Attr=sum(adult_df.isnull().sum())
#Number of instances with missing values
No_Missing_Values_Instances=sum(adult_df.isnull().values.any(axis=1))
#Stats Table
input_stats_df= pd.Series([No_Instances,No_missing_values_Attr,round(No_missing_values_Attr/Total_No_Attr_Values,4),No_Missing_Values_Instances,round(No_Missing_Values_Instances/No_Instances,4)],['Number of Instances','Number of Missing Values','Fraction of Missing Values over All Attr Values','Number of Missing Values in Instance','Fraction of instances with missing values instances'])
print(input_stats_df)

#We are replacing null with 'missing' since it will be used later prupose

print("\033[1m",'\nHandling missing values\n',"\033[0m",'The next steps are handling null values\n','1. Replacing "nan" with "missing"\n' ,'2. Creating a new column called "missing_flag" which is a flag column to indicate missing instances\n')
print("\033[1m",'These processess will aid in handling the null values and will help in forming the instances for D1` and D2` \n',"\033[0m")
dt_df= adult_df.copy()
dt_df= dt_df.fillna(-12345)
dt_df=dt_df[dt_df.columns].astype(str)
dt_df= dt_df.replace(to_replace = '-12345', value ='missing') 
#dt_df

print('1. Replacing "nan" with "missing"',"\033[1m",' - Done\n',"\033[0m")

query_details="";
for name in range(len(dt_df.columns)):
    if name==0 and dt_df.dtypes[name]=='object':
        query_details=dt_df.columns[name]+'=="missing" or '
    elif name+1==len(dt_df.columns) and dt_df.dtypes[name]=='object':
        query_details=query_details+dt_df.columns[name]+'=="missing"'
    elif dt_df.dtypes[name]=='object':
        query_details=query_details+dt_df.columns[name]+'=="missing" or '
    
#Creating Missing Flag
missing_dt_df =dt_df.query(query_details).copy()
missing_dt_df['missing_flag']=1

query_details="";
for name in range(len(dt_df.columns)):
    if name==0 and dt_df.dtypes[name]=='object':
        query_details=dt_df.columns[name]+'!="missing" and '
    elif name+1==len(dt_df.columns) and dt_df.dtypes[name]=='object':
        query_details=query_details+dt_df.columns[name]+'!="missing"'
    elif dt_df.dtypes[name]=='object':
        query_details=query_details+dt_df.columns[name]+'!="missing" and '
    
# Missing Flag
non_missing_dt_df =dt_df.query(query_details).copy()
non_missing_dt_df['missing_flag']=0

dt_df=pd.concat([non_missing_dt_df,missing_dt_df])
print('2. Creating a new column called "missing_flag" which is a flag column to indicate missing instances',"\033[1m",' - Done\n',"\033[0m")

dt_df= dt_df[['age', 'workclass', 'education', 'marital_status',
       'occupation', 'relationship', 'race', 'sex', 'capitalgain',
       'capitalloss', 'hoursperweek', 'native_country', 'class_name',
       'missing_flag','education_num']]



dt_df,dt_enc_dic,dt_dec_dic=encode_decode_df(dt_df)
print('\nEncoding of the data set -',"\033[1m",' Completed\n',"\033[0m")

for keys in dt_enc_dic:
    if keys !='missing_flag' and keys !='class_name':
        print('Attribute Name:',"\033[1m" ,keys,"\033[0m",'\n')
        for keys1 in  dt_enc_dic[keys]:
            if keys1!='missing':
                print('Val Name: ',"\033[1m" ,keys1,"\033[0m",'Encoding Value: ',"\033[1m",dt_enc_dic[keys][keys1],"\033[0m",'\n')
        print('----------------------------')
        

print('\n Removing the missing instances for building the Tree Classifier -',"\033[1m",' Completed \n','"\033[0m"')
#Getting the columns which has missing values and then applying filter on the dataframe
#col_rem_dic ={}
dt_df_test=pd.concat([dt_df])
for keys in dt_enc_dic:
    for keys1 in dt_enc_dic[keys]:
        if keys1=='missing':
            dt_df_test=dt_df_test[dt_df_test[keys]!=dt_enc_dic[keys][keys1]]

#split the data into traning and test sets
x_train,x_test,y_train,y_test  = train_test_split(dt_df_test.iloc[:,:12], dt_df_test.iloc[:,12:13],test_size=0.20)

x_train,x_test,y_train,y_test=test_instances_checker(x_train,x_test,y_train,y_test)
baseline_test_prop=print_train_test_ratio(x_train,x_test,y_train,y_test)

# initialise the decision tree 
print("\033[1m",'\n Building the Decision Tree Classifier.',"\033[0m")
print("\033[1m",'\n Note:',"\033[0m",' Post Pruning has been used to identify the best suited "ccp_alpha" after testing for various scenarios')
print('\n Fit the Classifier with the Training Data')
clf=tree.DecisionTreeClassifier(criterion='entropy',splitter='best',ccp_alpha=0.00028225386)
#clf=tree.DecisionTreeClassifier(criterion='entropy',splitter='best',ccp_alpha=0.00016482435)

#fit the tree model to the training data
clf.fit(x_train,y_train)

#Pruning_Param(clf,x_train,y_train,x_test,y_test)

baseline_error_rate=all_metrics(x_train.to_numpy(),y_train.to_numpy(),x_test.to_numpy(),y_test.to_numpy(),clf)
print("\033[1m",'\n The Error rates of initial model will be later compared with the D1` and D2` Error Rate later',"\033[0m")
print('--------------------------------------------------------------------------------------------')

#Building the D_prime
D_prime_part1=dt_df[dt_df['missing_flag']==1]
D_prime_part2=pd.concat([dt_df[dt_df['missing_flag']==0]],axis=1).sample(n=len(D_prime_part1))
D_prime=pd.concat([D_prime_part1,D_prime_part2])
print("\033[1m"'\n Building the D_prime DataSet',"\033[0m")
print('\n-------------------')
print('\n 1. The D_prime is built containing the all missing instances + the random selection of equal amount of instances from original data set D')

#Creating D_1 -by combining the missing values  and randomly sampled data

#D_1_part1=D_prime[D_prime['missing_flag']==1]
#D_1_part2=pd.concat([x_train,y_train],axis=1).drop_duplicates().sample(n=len(D_1_part1))
D_1=D_prime.copy()
print("\033[1m"'\n Building the D1` Training DataSet',"\033[0m")
print('\n-------------------')
print('\n 1. The D1` is built containing the all missing instances + all instances of D_prime')
print('\n 2. The missing instances are replaced with the word "missing"')

# initialise the decision tree for D1
print("\033[1m",'\nDecision Tree D1`',"\033[0m")
print('---------------------')
print('\n1. Building the Decision Tree Classifier for D1`.')
print("\033[1m",'\n Note:',"\033[0m",' Post Pruning has been used to identify the best suited "ccp_alpha" after testing for various scenarios')
print('\n2.  Fit the Classifier with the Training Data')
print('\n3.  Use the Trained Classifier with the D`s Test Data')
print("\033[1m",'\n Note:',"\033[0m",' The test data is same the D`s because we are comparing the error rates with missing data')
x1_train=D_1.iloc[:,:12]
y1_train=D_1.iloc[:,12:13]
#x1_test=dt_df_test.iloc[:,:12]
#y1_test=dt_df_test.iloc[:,12:13]
#clf_1=tree.DecisionTreeClassifier(criterion='entropy',splitter='best',ccp_alpha=0.00039226191)
clf_1=tree.DecisionTreeClassifier(criterion='entropy',splitter='best',ccp_alpha=0.00074837349)


x1_train,x1_test,y1_train,y1_test=test_instances_checker(x1_train,x_test,y1_train,y_test)
print_train_test_ratio(x1_train,x1_test,y1_train,y1_test)

print('\nWe are use the same test scenarios as our baseline model')
print('\nThe above test proportion is very high so we will select the proportion of test scenarios equal to our baseline model -will run it over many iterations of different test cases  and average it ')
#This is commented here but was used during testing to find the best parameter 
#Pruning_Param(clf_1,x1_train,y1_train,x_test,y_test)

#fit the tree model to the training data
clf_1.fit(x1_train,y1_train)

#Adjusting the test size of the data according to the baseline proportion
x1_size=len(x1_train)
x1_test_prop= round(x1_size*baseline_test_prop/(1-baseline_test_prop))

x1_error_rate=[]
for i in range(10):
    x1_test_combined=x_test.merge(y_test,left_index=True,right_index=True).sample(n=x1_test_prop)
    x1_test=x1_test_combined.iloc[:,:12]
    y1_test=x1_test_combined.iloc[:,12:13]
    x1_error_rate.append(all_metrics(x1_train.to_numpy(),y1_train.to_numpy(),x1_test.to_numpy(),y1_test.to_numpy(),clf_1))

#all_metrics(x1_train.to_numpy(),y1_train.to_numpy(),x_test.to_numpy(),y_test.to_numpy(),clf_1)

x1_error_rate=np.average(x1_error_rate)
print_train_test_ratio(x1_train,x1_test,y1_train,y1_test)

print('--------------------------------------------------------------------------------------------')

#Creating D_2 -by combining replacing missing values with popular values and then adding randomly sampled data
print("\033[1m",'\n Building the D2` Training DataSet','"\033[0m"')
print('\n-------------------')
print('\n 1. The D2` is build containing the all missing instances + the random selection of equal amount of instances from original dataSet D')
print('\n 2. The missing instances are replaced with the most popular instances from D')
D_2_part1=D_prime[D_prime['missing_flag']==1]
D_2_part1_most_occuring=pd.DataFrame()
D_2_most_popular=[]
for names in dt_df.columns:
    D_2_most_popular.append(dt_df[names].groupby(dt_df[names]).count().idxmax())
D_2_most_popular=np.array(D_2_most_popular)
D_2_part1_most_occuring=D_2_part1_most_occuring.append(pd.DataFrame(D_2_most_popular).T)
D_2_part1_most_occuring.columns=dt_df.columns

for keys in dt_enc_dic:
    for keys1 in dt_enc_dic[keys]:
        if keys1=='missing':
            #dt_df_test=dt_df_test[dt_df_test[keys]!=dt_enc_dic[keys][keys1]]
            D_2_part1[keys].loc[D_2_part1[keys]== dt_enc_dic[keys][keys1]]=int(D_2_part1_most_occuring[keys].to_numpy())

D_2_part2=D_prime[D_prime['missing_flag']==0]

print('\nPlease ignore the below exception\n')

D_2=pd.concat([D_2_part1,D_2_part2])

# initialise the decision tree for D2
#clf_2=tree.DecisionTreeClassifier(criterion='entropy',splitter='best',ccp_alpha=0.00073887717)
print("\033[1m",'\nDecision Tree D2`','"\033[0m"')
print('---------------------')
print('\n Building the Decision Tree Classifier for D1`.')
print("\033[1m",'\n Note:',"\033[0m",' Post Pruning has been used to identify the best suited "ccp_alpha" after testing for various scenarios')
print('\n Fit the Classifier with the Training Data')
print('\n Use the Trained Classifier with the D`s Test Data')
print("\033[1m",'\n Note:',"\033[0m",' The test data is same the D`s because we are comparing the error rates with missing data')

clf_2=tree.DecisionTreeClassifier(criterion='entropy',splitter='best',ccp_alpha=0.00044484672)

x2_train=D_2.iloc[:,:12]
y2_train=D_2.iloc[:,12:13]
#x2_test=dt_df_test.iloc[:,:12]
#y2_test=dt_df_test.iloc[:,12:13]

x2_train,x2_test,y2_train,y2_test=test_instances_checker(x2_train,x_test,y2_train,y_test)
print_train_test_ratio(x2_train,x2_test,y2_train,y2_test)
print('\nWe are use the same test scenarios as our baseline model')
print('\nThe above test proportion is very high so we will select the proportion of test scenarios equal to our baseline model -will run it over many iterations of different test cases  and average it ')


#This is commented here but was used during testing to find the best parameter 
#Pruning_Param(clf_2,x2_train,y2_train,x_test,y_test)

#Fit the classification of the training model for D2 Prime
clf_2.fit(x2_train,y2_train)

#Adjusting the test size of the data according to the baseline proportion
x2_size=len(x2_train)
x2_test_prop= round(x2_size*baseline_test_prop/(1-baseline_test_prop))

x2_error_rate=[]
for i in range(10):
    x2_test_combined=x_test.merge(y_test,left_index=True,right_index=True).sample(n=x2_test_prop)
    x2_test=x2_test_combined.iloc[:,:12]
    y2_test=x2_test_combined.iloc[:,12:13]
    x2_error_rate.append(all_metrics(x2_train.to_numpy(),y2_train.to_numpy(),x2_test.to_numpy(),y2_test.to_numpy(),clf_2))

x2_error_rate=np.average(x2_error_rate)
print_train_test_ratio(x2_train,x2_test,y2_train,y2_test)
print(x2_error_rate)


print('--------------------------------------CONCLUSION------------------------------------------------------')
print('\nThe Baseline Error Rate:',baseline_error_rate)
print('\nThe D1` Error Rate(Null as "missing"):',x1_error_rate)
print('\nThe D2` Error Rate(by Imputation):',x2_error_rate)

print('--------------------------------------------------------------------------------------------')



