import numpy as np;
import pandas as pd;
import matplotlib.pyplot as plt;
from sklearn.cluster import KMeans;


'''Defining the K-Means CLustering using This Function
        1. Get the input number of Clusters, the dataframe details and the K-value for which the scatter plot matrix should be plotter
        2. Use the K-Means clustering from Scikit Learn to classify the data for the 6 feature vectors
        3. Plot the Scatter Matrix for each pair of attributes
        4. Get the Cluster Centroid and append it to the dataframe. This will be used to calculate the Within Cluster distance
        5. Calculate the 'Within Cluster' Distance
        6. Calculate the 'Between Cluster' Distance
        7. Calculate the 'Score' for that K-Means
        8. Return the values of the WC, BC and Score '''
def K_Means_Function(df,number_cluster,show_scatter_plot_cluster_number=0):
    
    print('\n--------------------------------------------------------------------')
    print("\033[1m",'\nK-Means\n','Number of Clusters: ',"\033[0m",number_cluster)
    K_Means = KMeans(n_clusters=number_cluster,random_state=0).fit(df[df.columns])
    df['K_MEANS_CLASS']=K_Means.labels_
    
    #Printing the Scattter Matrix for All attributes
    if show_scatter_plot_cluster_number==number_cluster:
        largest_val=int(df[df.columns[:6]].max().nlargest(1))
        df_column=df.columns[:6]
        fig = plt.figure()
        print("\033[1m",'\nThe Scatter Plot Matrix:',"\033[0m")
        c_counter=0
        #fig.clear(True)
        for i in range(len(df_column)):
            for j in range(len(df_column)):
                if j>i:
                    c_counter+=1
                    dfname = 'ax'+str(c_counter) 
                    vars()[dfname]= fig.add_subplot(5,3,c_counter)
                    scatter = vars()[dfname].scatter(df[df_column[i]],df[df_column[j]] ,c=df['K_MEANS_CLASS'],marker='o')
                    vars()[dfname].set_title(df_column[i]+ ' vs '+df_column[j])
                    vars()[dfname].set_xlabel(df_column[i])
                    vars()[dfname].set_ylabel(df_column[j])
                    legend1 = vars()[dfname].legend(*scatter.legend_elements(),loc="upper right", title="Classes")
                    vars()[dfname].add_artist(legend1)
                    #vars()[dfname].set_xlim([0,30000)
                    #vars()[dfname].set_ylim([0,30000)
        plt.rc('figure',figsize=(25,30))
        plt.show()
    
    #Finding the Distance between Cluster and the Distince within Cluster
    K_Means_Centroids_temp=K_Means.cluster_centers_
    K_Means_rows,K_Means_cols= K_Means_Centroids_temp.shape

    K_Means_df_col_name=[]
    for i in range(K_Means_cols):
        col_name = 'Centroid_0'+str(i)
        K_Means_df_col_name.append(col_name)
    
    K_Means_Centroids=pd.DataFrame(K_Means_Centroids_temp,columns=K_Means_df_col_name)
    #K_Means_Centroids
    df=df.merge(K_Means_Centroids,left_on='K_MEANS_CLASS',right_index=True)
    df['SSD']= (pow(df['FRESH']-df['Centroid_00'],2) +  
    pow(df['MILK']-df['Centroid_01'],2) +
    pow(df['GROCERY']-df['Centroid_02'],2) +
    pow(df['FROZEN']-df['Centroid_03'],2) +
    pow(df['DETERGENTS_PAPER']-df['Centroid_04'],2) +
    pow(df['DELICASSEN']-df['Centroid_05'],2))
          
    #Calculating the WC Value
    WC=df['SSD'].sum()
    
    #Calculating the BC Value
    BC=0
    for i in range(K_Means_rows):
        for j in range(K_Means_rows):
            if j>i:
                BC+=np.sum(pow(K_Means_Centroids_temp[i]-K_Means_Centroids_temp[j],2))
    
    #Calculating the Score
    Score=BC/WC
    
    #Calculating Calinski-Harabaz Index
    CHIndex= (BC/WC)*(len(df)-number_cluster)/(number_cluster-1)
    
    print("\033[1m",'\nWC:',"\033[0m",WC,'|',"\033[1m",'BC:',"\033[0m",BC,'|',"\033[1m",'Score: ',"\033[0m",Score)
    
    dfname_1 = 'df_'+str(number_cluster) 
    vars()[dfname_1]= df.copy()
    return WC,BC,Score,CHIndex



'''------------------------------------------------MAIN PROGRAM STARTS HERE------------------'''
#The main code starts here
print("\033[1m",'\nClustering',"\033[0m")
df = pd.read_csv("wholesale_customers.csv")
print('The Data Set is imported successfully \n')

#Formatting operations
df.columns=map(str.upper,df.columns)
df.columns=map(str.strip,df.columns)
#removing unwanted columns
df.drop(['CHANNEL','REGION'],axis=1,inplace=True)
print("\033[1m",'Some Data Cleaning Operations Performed\n',"\033[0m",'1.Removal of the Channel and Region columns as it is not required\n','2. Using standard names for the columns')

print("\033[1m",'Printing out the Stats below\n',"\033[0m")
print('-----------------------------\n')
column_name=['Attribute','Mean','Min','Max']
Attribute_Details= pd.DataFrame(columns=column_name)

for name in df.columns:
    Attribute_Details_temp=pd.DataFrame([[name,df[name].mean(),df[name].min(),df[name].max()]],columns=['Attribute','Mean','Min','Max'])
    Attribute_Details=Attribute_Details.append(Attribute_Details_temp,ignore_index=True)

Attribute_Details.set_index=Attribute_Details['Attribute']
print(Attribute_Details)

WC=[]
BC=[]
Score=[]
clusters=[]
CHIndex=[]
show_scatter_plot_cluster_number=3
for i in range(2, 11):
    a,b,c,d= K_Means_Function(df,i,show_scatter_plot_cluster_number)    
    clusters.append(str(i))
    WC.append(a)
    BC.append(b)
    Score.append(c)
    CHIndex.append(d)

metrics_df=pd.DataFrame([np.array(clusters),np.array(WC),np.array(BC),np.array(Score)],index=['Clusters','WC','BC','Score'],columns=np.array(clusters))
print("\033[1m",'\nOverall Metrics',"\033[0m")
metrics_df

print("\033[1m",'\n Plotting the Metrics to showing the best K-Means Cluster Value that can be used',"\033[0m")

met_fig= plt.figure()
metax = met_fig.add_subplot(4,1,1)
metax.plot(clusters,WC,'o-')
#metax.set_xlabel('Number of Clusters')
metax.set_ylabel('WC')
metax.set_title('WC Vs Number of Clusters')

metax_1 = met_fig.add_subplot(4,1,2)
metax_1.plot(clusters,BC,'o-')
#metax_1.set_xlabel('Number of Clusters')
metax_1.set_ylabel('BC')
metax_1.set_title('BC Vs Number of Clusters')

metax_2 = met_fig.add_subplot(4,1,3)
metax_2.plot(clusters,Score,'o-')
metax_2.set_xlabel('Number of Clusters')
metax_2.set_ylabel('Score')
metax_2.set_title('Score Vs Number of Clusters')



cluster_selection=[(1,'1st'),(3,'2nd'),(8,'3rd')]
for i,label in cluster_selection:
    metax.annotate(label,xy=(metrics_df[metrics_df.columns[i]]['Clusters'],metrics_df[metrics_df.columns[i]]['WC']+100), 
                    xytext=(metrics_df[metrics_df.columns[i]]['Clusters'],metrics_df[metrics_df.columns[i]]['WC']+300),
                    arrowprops=dict(facecolor='black',headwidth=10,width=7,headlength=7),
                    horizontalalignment='left',verticalalignment='top')
    metax_1.annotate(label,xy=(metrics_df[metrics_df.columns[i]]['Clusters'],metrics_df[metrics_df.columns[i]]['BC']+100), 
                    xytext=(metrics_df[metrics_df.columns[i]]['Clusters'],metrics_df[metrics_df.columns[i]]['BC']+300),
                    arrowprops=dict(facecolor='black',headwidth=10,width=7,headlength=7),
                    horizontalalignment='left',verticalalignment='top')
    metax_2.annotate(label,xy=(metrics_df[metrics_df.columns[i]]['Clusters'],metrics_df[metrics_df.columns[i]]['Score']+0.2), 
                    xytext=(metrics_df[metrics_df.columns[i]]['Clusters'],metrics_df[metrics_df.columns[i]]['Score']+0.5),
                    arrowprops=dict(facecolor='black',headwidth=10,width=7,headlength=7),
                    horizontalalignment='left',verticalalignment='top')
plt.rc('figure',figsize=(20,30))
plt.show()

